﻿internal class Program
{
    private static void Main(string[] args)
    {
        int conteo = 0;
        int conteo2 = 0;
        int conteo3 = 15;
        while (conteo < 8)
        {
            while (conteo2 < 9)
            {
                Console.Write("x\t");
                conteo2++;
            }
            Console.WriteLine("\n\nx\t\t\t\t\t\t\t\tx");
            conteo++;
            conteo3++;
            while (conteo3 > 18)
            {
                conteo2 = 0;
                conteo3 = 0;
                Console.WriteLine(" ");
            }
        }
        Console.WriteLine("");
        Console.WriteLine("");
        conteo = 0;
        conteo2 = 0;
        conteo3 = 15;
        while (conteo < 8)
        {
            while (conteo2 < 9)
            {
                Console.Write("x\t");
                conteo2++;
            }
            Console.WriteLine("\n\nx\t\t\t\t\t\t\t\tx");
            conteo++;
        }
        Console.WriteLine(" ");
        conteo2 = 0;
        while (conteo2 < 9)
        {
            Console.Write("x\t");
            conteo2++;
        }
        Console.ReadKey();
    }
}