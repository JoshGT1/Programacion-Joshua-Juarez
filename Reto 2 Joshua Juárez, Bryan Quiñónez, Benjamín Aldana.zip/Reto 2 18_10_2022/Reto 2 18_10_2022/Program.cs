﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_2_18_10_2022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] niveles = new int[5];
            int[] adultos = new int[5];
            int[] niños = new int[5];
            int nivel = 1;
            for (int i = 0; i < 5; i++)
            {
                niveles[i] = nivel;
                Console.WriteLine("Ingrese el número de adultos que están en el nivel: " + nivel);
                adultos[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el número de niños que están en el nivel: " + nivel);
                niños[i] = int.Parse(Console.ReadLine());
                nivel++;
            }
            Console.Clear();
            int mayor = niños[0];
            for (int i = 1; i < 5; i++)
            {
                if (niños[i] > mayor)
                {
                    mayor = niños[i];
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Nivel: " + niveles[i] + "\n");
                Console.WriteLine("Número de adultos viviendo: " + adultos[i]);
                Console.WriteLine("Número de niños viviendo: " + niños[i] + "\n");

            }
            for (int i = 0; i < 5; i++)
            {
                if (niños[i] == mayor)
                {
                    Console.WriteLine("Nivel con mayor cantidad de niños: " + niveles[i]);
                }
            }
            Console.ReadKey();
        }
    }
}
