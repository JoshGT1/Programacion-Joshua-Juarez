﻿

namespace R1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 2 funciones de numero, int , double
            int x = 2; double y = 3.12;
            string numero = "es un numero entero";
            // 1 funcion de texto
            Console.WriteLine("Reto 1 Numero entero y decimal");
            Console.WriteLine(" ");
            Console.WriteLine(x +" "  + numero +  " y " + y + " es un numero decimal");
            Console.WriteLine("Pulse una tecla para terminar...");
            Console.ReadKey();
            //concatenar
        }

    }
}