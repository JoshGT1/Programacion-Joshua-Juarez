﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_1_18_10_2022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] niveles = new int[5];
            int[] personas = new int[5];
            int nivel = 1;
            for (int i = 0; i < 5; i++)
            {
                niveles[i] = nivel;
                Console.WriteLine("Ingrese el número de personas que están en el nivel: " + nivel);
                nivel++;
                personas[i] = int.Parse(Console.ReadLine());
            }
            Console.Clear();
            int menor = personas[0];
            for (int i = 1; i < 5; i++)
            {
                if (personas[i] < menor)
                {
                    menor = personas[i];
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Nivel: " + niveles[i]);
                Console.WriteLine("Número de personas viviendo: " + personas[i]+ "\n");
            }
            for (int i = 0; i < 5; i++)
            {
                if (personas[i] == menor)
                {
                    Console.WriteLine("Nivel de menor cantidad de personas: " + niveles[i]);
                }
            }
            Console.ReadKey();
        }
    }
}
