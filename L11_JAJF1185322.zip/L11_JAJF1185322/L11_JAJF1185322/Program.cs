﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_JAJF1185322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("¿Cuántos números desea ingresar?");
            int N = int.Parse(Console.ReadLine());
            Console.Clear();
            int[] numeros = new int[N];
            for (int i = 0; i < N; i++)
            {
                Console.WriteLine("Ingrese número");
                numeros[i]=int.Parse(Console.ReadLine());
            }
            Console.Clear();
            Console.WriteLine("Los números ingresados son:");
            for (int i = 0; i < N; i++)
            {
                Console.WriteLine(numeros[i]);

            }
            int sumanum = numeros[0];
            for (int i = 1; i < N; i++)
            {
                sumanum = numeros[i] + sumanum;
            }
            Console.WriteLine("\nLa suma del arreglo es: " + sumanum + "\n");
            Console.WriteLine("La longitud del arreglo es: "+N+"\n");

            //Las pociciones pares e impares que serán utilizadas serás las de la máquina y sus vectores (0, 2 y 4 en este caso).
            
            int sumaPar = numeros[0];
            for (int i = 1; i < N; i++)
            {
                i++;
                if (i < N)
                {
                    sumaPar = numeros[i] + sumaPar;
                }
            }
            Console.WriteLine("La suma de las posiciones pares (Según la máquina) es de: " + sumaPar + "\n");
            int sumaImpar = numeros[1];
            for (int i = 2; i < N; i++)
            {
                i++;
                if (i<N)
                {
                    sumaImpar = numeros[i] + sumaImpar;
                }
            }
            Console.WriteLine("La suma de las posiciones impares (Según la máquina) es de: " + sumaImpar + "\n");
            Console.ReadKey();
        }
    }
}
