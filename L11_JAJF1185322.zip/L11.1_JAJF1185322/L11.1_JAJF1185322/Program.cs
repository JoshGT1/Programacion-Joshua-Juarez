﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11._1_JAJF1185322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Creación de Vectores para las notas de la secciones
            double[] Seccion1 = new double[10];
            double[] Seccion2 = new double[10];
            int numero = 1;

            //Nombre, sección y carné
            Console.WriteLine("Joshua A. Juárez F.\tSección: 10\tCarné:1185322");
            Console.WriteLine("Presionar cualquier tecla para ejecutar el programa");
            Console.ReadKey();

            //Pedir al usuario el ingreso de las notas de los estudiantes de la sección 1 y 2
            Console.WriteLine("Sección 1");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante " + numero);
                numero++;
                Seccion1[i] = Convert.ToDouble(Console.ReadLine());
            }
            Console.Clear();
            Console.WriteLine("Sección 2");
            numero = 1;
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante " + numero);
                numero++;
                Seccion2[i] = Convert.ToDouble(Console.ReadLine());
            }
            Console.Clear();

            //Porcentaje de Aprobados y Desaprovados de cada seeción
            int Aprobados = 0;
            int NoAprobados = 0;
            for (int i = 0; i < 10; i++)
            {
                if (Seccion1[i] >= 65)
                {
                    Aprobados = Aprobados + 1;
                }
                else
                {
                    NoAprobados = NoAprobados + 1;
                }
            }
            double APorcentaje;
            double NPorcentaje;
            APorcentaje = (Aprobados * 100)/10;
            NPorcentaje = (NoAprobados * 100)/10;
            Console.WriteLine("Sección 1\n");
            Console.WriteLine("El porciento de aprobados de la sección 1 es de: " + APorcentaje +"%");
            Console.WriteLine("El porciento de no aprobados de la sección 1 es de: " + NPorcentaje + "%");
            int AprobadosTotal = 0 + Aprobados;
            int NoAprobadosTotal = 0 + NoAprobados;
            Aprobados = 0;
            NoAprobados = 0;
            for (int i = 0; i < 10; i++)
            {
                if (Seccion2[i] >= 65)
                {
                    Aprobados = Aprobados + 1;
                }
                else
                {
                    NoAprobados = NoAprobados + 1;
                }
            }
            APorcentaje = (Aprobados * 100) / 10;
            NPorcentaje = (NoAprobados * 100) / 10;
            Console.WriteLine("\nSección 2\n");
            Console.WriteLine("El porciento de aprobados de la sección 2 es de: " + APorcentaje + "%");
            Console.WriteLine("El porciento de no aprobados de la sección 2 es de: " + NPorcentaje + "%");

            //Operaciones de porcentajes totales de aprovados y desaprovados
            AprobadosTotal = Aprobados + AprobadosTotal;
            double PorcentajeTotal = (AprobadosTotal * 100) / 20;
            NoAprobadosTotal = NoAprobados + NoAprobadosTotal;
            double PorcentajeTotal2 = (NoAprobadosTotal * 100) / 20;
            Console.WriteLine("\nLas 2 Secciones\n");
            Console.WriteLine("El porciento de aprobados de las 2 secciones es de: " + PorcentajeTotal + "%");
            Console.WriteLine("El porciento de no aprobados de las 2 secciones es de: " + PorcentajeTotal2 + "%");

            //Promedio de notas de cada sección
            double SumaT1 = 0;
            double SumaT2 = 0;
            for (int i = 0; i < 10; i++)
            {
                SumaT1 = SumaT1 + Seccion1[i];
                SumaT2 = SumaT2 + Seccion2[i];
            }
            double PromedioT1=SumaT1 / 10;
            double PromedioT2=SumaT2 / 10;
            double PromedioTotal = (SumaT1 + SumaT2) / 20;
            Console.WriteLine("\nEl promedio de notas de la sección 1 es de: " + PromedioT1);
            Console.WriteLine("El promedio de notas de la sección 2 es de: " + PromedioT2);
            Console.WriteLine("El promedio de notas de las dos secciones es de: " + PromedioTotal);

            //Cantidad de estudiantes que tengan un nota por encima de 90 y por debajo de 75
            int NumProm90 = 0;
            int NumProm75 = 0;
            for (int i = 0; i < 10; i++)
            {
                if (Seccion1[i] > 90)
                {
                    NumProm90 = NumProm90 + 1;
                }
                if (Seccion2[i] > 90)
                {
                    NumProm90 = NumProm90 + 1;
                }
                if (Seccion1[i] < 75)
                {
                    NumProm75 = NumProm75 + 1;
                }
                if (Seccion2[i] < 75)
                {
                    NumProm75 = NumProm75 + 1;
                }
            }
            Console.WriteLine("\nLa cantidad de estudiantes que tienen una nota por encima de 90 son: " + NumProm90);
            Console.WriteLine("La cantidad de estudiantes que tienen una nota por debajo de 75 son: " + NumProm75);
            Console.WriteLine("\nPresionar cualquier tecla para terminar el programa");
            Console.ReadKey();
        }
    }
}
