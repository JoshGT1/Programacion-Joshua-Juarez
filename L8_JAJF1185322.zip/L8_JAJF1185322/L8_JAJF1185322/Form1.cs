﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_JAJF1185322
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedItem)
            {
                case "Sumatoria":
                    tabControl1.SelectTab(tabPage1);
                    break;

                case "Factorial":
                    tabControl1.SelectTab(tabPage2);
                    break;

                case "Tablas de multiplicar":
                    tabControl1.SelectTab(tabPage3);
                    tabla_de_multiplicar();
                    break;

                case "Número perfecto":
                    tabControl1.SelectTab(tabPage4);
                    break;
            }
        }

 

        private void button2_Click(object sender, EventArgs e)
        {
            int numero=int.Parse(textBox1.Text);
            int resultado1 = ((numero + 1) * numero) / 2;
            label4.Text =resultado1.ToString();
        }

        private void tabla_de_multiplicar()
        {
            label5.Text = "            ";
            for (int a = 1; a < 11; a++)
            {
                label5.Text =label5.Text + a.ToString()+ "        ";
            }
            label5.Text = label5.Text + "\n";
            for (int x = 1; x < 11; x++)
            {
                label5.Text = label5.Text+ x.ToString()+"   ";
                for( int y = 1; y < 11; y++)
                {
                    label5.Text = label5.Text + "        " + (x * y).ToString();
                    // label5.Text = string.Format("{0}\t{1}", label5.Text, "n");
                }
                label5.Text = label5.Text + "\n";
            }
                
        }

        private bool NumeroPrimo()
        {
            int numeroNormal = int.Parse(textBox2.Text);
            int numerobox= ((int)(Math.Pow(2, numeroNormal)-1));
            int cuenta = 2;
            int end = numerobox - 1;
            bool ender = false;
            while (cuenta<end)
            {
                if (numerobox % cuenta == 0)
                {
                    cuenta = end - 1;
                    ender = true;
                }
                cuenta++;
            }
            return ender;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (NumeroPrimo())
            {
                int pruebat = int.Parse(textBox2.Text);
                int pruebaj = ((int)(Math.Pow(2, pruebat) - 1));
                int resultado = ((int)(Math.Pow(2, pruebat - 1) * pruebaj));
                label8.Text=(resultado + " El cual es un Número Perfecto");
            }
            else
            {
                int pruebat = int.Parse(textBox2.Text);
                int pruebaj = ((int)(Math.Pow(2, pruebat) - 1));
                int resultado = ((int)(Math.Pow(2, pruebat - 1) * pruebaj));
                label8.Text=(resultado + " El cual no es un Número Perfecto");
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
    