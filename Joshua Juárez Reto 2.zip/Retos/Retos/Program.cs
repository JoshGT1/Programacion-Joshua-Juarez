﻿int conteo = 0;
int conteo2 = 0;
int conteo3 = 15;
int conteo4 = 12;
while (conteo < 7)
{
    while (conteo2 < 9)
    {
        Console.Write("x\t");
        conteo2++;
    }
    Console.WriteLine("\n\nx");
    conteo++;
    conteo3++;
    conteo4++;
    while (conteo3 > 18)
    {
        conteo2 = 0;
        conteo3 = 0;
        Console.WriteLine(" ");
    }
    while (conteo4 > 18)
    {
        conteo2 = 0;
        Console.WriteLine();
        while (conteo2 < 9)
        {
            Console.Write("x\t");
            conteo2++;
        }
        conteo4 = 0;
        Console.WriteLine(" ");
    }
}
Console.WriteLine("");
Console.WriteLine("");
conteo = 0;
conteo2 = 0;
conteo3 = 15;
while (conteo < 8)
{
    while (conteo2 < 9)
    {
        Console.Write("x\t");
        conteo2++;
    }
    Console.WriteLine("\n\n\t\t\t\tx\t\t\t\t");
    conteo++;
}
Console.WriteLine(" ");
conteo2 = 0;
while (conteo2 < 9)
{
    Console.Write("x\t");
    conteo2++;
}
Console.ReadKey();