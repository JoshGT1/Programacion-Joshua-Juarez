﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12._1_JAJF1185322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] tabla1= new double[4,5];
            Random numeros= new Random();
            for (int i = 0; i < 5; i++)
            {
                for (int a = 0; a < 4; a++)
                {
                    tabla1[a,i] = numeros.Next(100);
                }
            }
            double sumaTotalTabla1 = 0;
            int contar = 0;
            for (int i = 0; i < 5; i++)
            {
                for (int a = 0; a < 4; a++)
                {
                    sumaTotalTabla1 = sumaTotalTabla1 + tabla1[a, i];
                    contar++;
                }
            }
            double promedioTabla1= sumaTotalTabla1 / contar;
            Console.WriteLine("Joshua A. Juárez F. 1185322");
            Console.WriteLine("Ejercicio #1 de laboratorio tabla T");
            Console.WriteLine("La suma total de todos los elementos de la matriz: " + sumaTotalTabla1);
            Console.WriteLine("El promedio de los elementos de la matriz es de: "+ promedioTabla1);
            Console.WriteLine("\nPresionar cualquier tecla para avanzar al ejercicio #2");
            Console.ReadKey();
            Console.Clear();
            double[,] matriz1 = new double[4, 4];
            double[,] matriz2 = new double[4, 4];
            double[,] matrizR = new double[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int a = 0; a < 4; a++)
                {
                    matriz1[a, i] = numeros.Next(200);
                    matriz2[a, i] = numeros.Next(300);
                }
            }
            for (int i = 0; i < 4; i++)
            {
                for (int a = 0; a < 4; a++)
                {
                    matrizR[a, i] = matriz1[a, i] + matriz2[a,i];
                }
            }
            Console.WriteLine("Ejercicio #2 de laboratorio suma de matrices");
            Console.WriteLine("La matriz resultante tiene los siguiente valores");
            for (int i = 1; i < 5; i++)
            {
                Console.Write("\t     Columna " + i); 
            }
            Console.WriteLine();
            int contarnum = 0;
            for (int i = 1; i < 5; i++)
            {
                    for (int y = 0; y < 4; y++)
                    {
                    if(y == 0)
                    {
                        Console.Write("Fila " + (i));
                    }
                        
                        Console.Write("\t\t" + matrizR[contarnum, y]);
                    }
                Console.WriteLine();
                contarnum++;
            }
            Console.ReadKey();
        }
    }
}
 