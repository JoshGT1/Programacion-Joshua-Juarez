﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_JAJF1185322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] Elementos = new int[14];
            Elementos[0] = 4;
            Elementos[1] = 5;
            Elementos[2] = 8;
            Elementos[3] = -5;
            Elementos[4] = 7;
            Elementos[5] = 25; 
            Elementos[6] = -1;
            Elementos[7] = 18;
            Elementos[8] = 1;
            Elementos[9] = -7;
            Elementos[10] = -2;
            Elementos[11] = 6;
            Elementos[12] = -4;
            Elementos[13] = 10;
            int SumaElementos = 0;

            for (int i = 0; i < 14; i++)
            {
                SumaElementos = Elementos[i] + SumaElementos;
            }

            int Contar = 0;
            for (int i = 0; i < 14; i++)
            {
                if (Elementos[i]>12)
                {
                    Contar = Contar + 1;
                }
            }

            double Porcentaje;
            Porcentaje = (Contar * 100) / 14;
            Console.WriteLine("Suma de todos los elementos: " + SumaElementos);
            Console.WriteLine("Él número de elementos que estás por encima del valor dados son: "+Contar);
            Console.WriteLine("El porcentaje que representan los números mayores al valor es de: "+Porcentaje+"%");
            Console.ReadKey();
        }
    }
}
