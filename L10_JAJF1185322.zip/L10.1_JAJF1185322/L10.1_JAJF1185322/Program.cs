﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10._1_JAJF1185322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string usuario;
            string contra;
            int contador = 1;
            while (contador < 4)
            {
                Console.WriteLine("Ingrese su nombre de usuario: ");
                usuario = Console.ReadLine();
                Console.WriteLine("Ingrese su contraseña");
                contra = Console.ReadLine();
                if (Login(usuario, contra)==true)
                {
                    Console.WriteLine("Acceso concedido");
                    contador = 4;
                }
                if (Login(usuario, contra) == false)
                {
                    Console.WriteLine("Acceso denegado, intente de nuevo");
                }
                contador++;
            }
            if (contador==4)
            {
                Console.Write("Número máximo de intentos permitidos");
            }
            Console.ReadKey();
        }
        static bool Login(string Nombre, string Contraseña)
        {
            bool Acceso = false;
            if (Nombre == "usuario1" && Contraseña == "asdasd")
            {
                Acceso = true;
            }
            return Acceso;
        }
    }
}
