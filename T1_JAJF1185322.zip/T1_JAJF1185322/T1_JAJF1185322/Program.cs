﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Ingrese Nombre");
        string sNombre = Console.ReadLine();
        Console.WriteLine("Ingrese Edad");
        string sEdad = Console.ReadLine();
        Console.WriteLine("Ingrese Carrera");
        string sCarrera = Console.ReadLine();
        Console.WriteLine("Ingrese Carné");
        string sCarné = Console.ReadLine();
        Console.WriteLine(" ");
        Console.WriteLine("Mi segundo programa");
        Console.WriteLine(" ");
        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carné: " + sCarné);
        Console.WriteLine(" ");
        Console.Write("Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ". Mi número de carné es; " + sCarné);
        Console.ReadKey();
    }
}