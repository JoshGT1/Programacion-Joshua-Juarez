﻿internal class Program
{
    private static void Main(string[] args)
    {
        byte dia;
        string mes;
        int toshi;
        string n = "Su signo del zodiaco es: ";
        Console.WriteLine("¿Cuál es su día de nacimiento? (Ingresar número)");
        dia = Convert.ToByte(Console.ReadLine());
        Console.WriteLine("¿Cuál es su mes de nacimiento? (Ejemplo: Abril)");
        mes = Console.ReadLine();
        Console.WriteLine("¿Cuál es su año de nacimiento? (Ingresar número)");
        toshi = int.Parse(Console.ReadLine());
        Console.Clear();
        switch (mes)
        {
            case "Enero":
                if (dia <= 19)
                {
                    Console.WriteLine(n + "Capricornio");
                }
                else
                {
                    Console.WriteLine(n + "Acuario");
                }
                break;

            case "Febrero":
                if (dia <= 18)
                {
                    Console.WriteLine(n + "Acuario");
                }
                else
                {
                    Console.WriteLine(n + "Piscis");
                }
                break;

            case "Marzo":
                if (dia <= 20)
                {
                    Console.WriteLine(n + "Piscis");
                }
                else
                {
                    Console.WriteLine(n + "Aries");
                }
                break;

            case "Abril":
                if (dia <= 19)
                {
                    Console.WriteLine(n + "Aries");
                }
                else
                {
                    Console.WriteLine(n + "Tauro");
                }
                break;

            case "Mayo":
                if (dia <= 20)
                {
                    Console.WriteLine(n + "Tauro");
                }
                else
                {
                    Console.WriteLine(n + "Géminis");
                }
                break;

            case "Junio":
                if (dia <= 20)
                {
                    Console.WriteLine(n + "Géminis");
                }
                else
                {
                    Console.WriteLine(n + "Cancer");
                }
                break;

            case "Julio":
                if (dia <= 22)
                {
                    Console.WriteLine(n + "Cancer");
                }
                else
                {
                    Console.WriteLine(n + "Leo");
                }
                break;

            case "Agosto":
                if (dia <= 22)
                {
                    Console.WriteLine(n + "Leo");
                }
                else
                {
                    Console.WriteLine(n + "Virgo");
                }
                break;

            case "Septiembre":
                if (dia <= 22)
                {
                    Console.WriteLine(n + "Virgo");
                }
                else
                {
                    Console.WriteLine(n + "Libra");
                }
                break;

            case "Octubre":
                if (dia <= 22)
                {
                    Console.WriteLine(n + "Libra");
                }
                else
                {
                    Console.WriteLine(n + "Escorpio");
                }
                break;

            case "Noviembre":
                if (dia <= 21)
                {
                    Console.WriteLine(n + "Escorpio");
                }
                else
                {
                    Console.WriteLine(n + "Sagitario");
                }
                break;

            case "Diciembre":
                if (dia <= 21)
                {
                    Console.WriteLine(n + "Sagitario");
                }
                else
                {
                    Console.WriteLine(n + "Capricornio");
                }
                break;
        }
        Console.ReadKey();
    }
}