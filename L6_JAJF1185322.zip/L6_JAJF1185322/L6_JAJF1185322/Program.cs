﻿using System.Runtime;

internal class Program
{
    static void ejercicio1()
    {
        Console.WriteLine("Ejercicio 1");
        Console.WriteLine("Ingrese el número de mes");
        int mes = int.Parse(Console.ReadLine());
        switch (mes)
        {
            case 1:
                Console.WriteLine("MES: Enero");
                break;
            case 2:
                Console.WriteLine("MES: Febrero");
                break;
            case 3:
                Console.WriteLine("MES: Marzo");
                break;
            case 4:
                Console.WriteLine("MES: Abril");
                break;
            case 5:
                Console.WriteLine("MES: Mayo");
                break;
            case 6:
                Console.WriteLine("MES: Junio");
                break;
            case 7:
                Console.WriteLine("MES: Julio");
                break;
            case 8:
                Console.WriteLine("MES: Agosto");
                break;
            case 9:
                Console.WriteLine("MES: Septiembre");
                break;
            case 10:
                Console.WriteLine("MES: Octubre");
                break;
            case 11:
                Console.WriteLine("MES: Noviembre");
                break;
            case 12:
                Console.WriteLine("MES: Diciembre");
                break;
            default:
                Console.WriteLine("Error: El número a ingresar debe estar entre contenido entre 1 y 12");
                break;
        }
        Console.ReadKey();
    }

    static void ejercicio2()
    {
        Console.WriteLine("Ejercicio 2");
        Console.WriteLine("Número 1: ");
        int a = int.Parse(Console.ReadLine());
        Console.WriteLine("Número 2: ");
        int b = int.Parse(Console.ReadLine());
        Console.WriteLine("Número 3: ");
        int c = int.Parse(Console.ReadLine());
        if (a > b)
        {
            if (a > c)
            {
                Console.WriteLine("RESULTADO: " + a);
            }
            else
            {
                if (a == c)
                {
                    Console.WriteLine("RESULTADO: " + a + " y " + c);
                }
                else
                {
                    Console.WriteLine("RESULTADO: " + c);
                }
            }
        }
        else
        {
            if (a == b)
            {
                if (a > c)
                {
                    Console.WriteLine("RESULTADO: " + a + " y " + b);
                }
                else
                {
                    if (a == c)
                    {
                        Console.WriteLine("RESULTADO: " + a + ", " + b + " y " + c);
                    }
                    else
                    {
                        Console.WriteLine("RESULTADO: " + c);
                    }
                }
            }
            else
            {
                if (b > c)
                {
                    Console.WriteLine("RESULTADO: " + b);
                }
                else
                {
                    if (b == c)
                    {
                        Console.WriteLine("RESULTADO: " + b + " y " + c);
                    }
                    else
                    {
                        Console.WriteLine("RESULTADO: " + c);
                    }
                }
            }

        }
        Console.ReadKey();
    }
    private static void Main(string[] args)
    {
        /* Si se quiere activar el ejercicio 1 escribir "ejercicio1();" en el siguiente espacio en blanco
           Si se quiere activar el ejercicio 2 escribir "ejercicio2();" en el siguiente espacio en blanco */
        ejercicio2();
    }
}