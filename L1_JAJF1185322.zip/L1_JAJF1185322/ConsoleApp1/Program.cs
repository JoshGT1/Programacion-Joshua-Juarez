﻿class Program
{

    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy " + Nombre);

        /* La diferenica entre WriteLine y Write es que WriteLine escribe el texto pedido en una sola línea, mientras que write escribe lo solicitado en una misma línea */

        Console.Write("Hola Mundo ");
        Console.Write("soy " + Nombre);
        Console.ReadKey();
    }
}
