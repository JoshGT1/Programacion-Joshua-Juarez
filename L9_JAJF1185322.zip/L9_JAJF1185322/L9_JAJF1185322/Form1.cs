﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_JAJF1185322
{
    public partial class Form1 : Form
    {
        Automovil objAutomovil = new Automovil();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            objAutomovil.DefinirModelo(int.Parse(textBox1.Text));
            objAutomovil.DefinirPrecio(Convert.ToDouble(textBox2.Text));
            objAutomovil.DefinirMarca(textBox3.Text);
            objAutomovil.DefinirTipoCambio(Convert.ToDouble(textBox4.Text));
            textBox6.Text = objAutomovil.MostrarInformación();
            button2.Enabled = true;
            button3.Enabled = true;
            tabControl1.SelectTab(tabPage2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            objAutomovil.AplicarDescuento(Convert.ToDouble(textBox5.Text));
            textBox6.Text = objAutomovil.MostrarInformación();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            objAutomovil.CambiarDisponibilidad();
            textBox6.Text = objAutomovil.MostrarInformación();
        }
    }
}
