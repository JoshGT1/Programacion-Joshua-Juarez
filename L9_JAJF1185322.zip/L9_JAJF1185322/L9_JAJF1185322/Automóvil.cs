﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_JAJF1185322
{
    internal class Automovil
    {
        private int modelo;
        private double precio;
        private string marca;
        private bool disponible;
        private double tipoCambioDolar;
        private double descuentoAplicado;

        public Automovil()
        {
            this.modelo = 2019;
            this.precio = 10000.00;
            this.marca = "";
            this.disponible = false;
            this.tipoCambioDolar = 7.50;
            this.descuentoAplicado = 0.00;
        }

        public void DefinirModelo(int unModelo)
        {
            modelo=unModelo;
        }

        public void DefinirPrecio(double unPrecio)
        {
            precio = unPrecio;
        }

        public void DefinirMarca(string unaMarca)
        {
            marca = unaMarca;
        }

        public void DefinirTipoCambio(double unTipoCambio)
        {
            tipoCambioDolar = unTipoCambio;
        }

        public void CambiarDisponibilidad()
        {
            if (disponible == true)
            {
                disponible=false;
            }
            else
            {
                disponible=true;
            }
        }

        public string MostrarDisponibilidad()
        {
            string result;
            if (disponible == true)
            {
                result = "Disponible.";
            }
            else
            {
                result = "No se encuentra disponible actualmente.";
            }
            return result;
        }

        public string MostrarInformación()
        {
            string Información="Marca: "+marca+ ". \r\nModelo: " + modelo+ ". \r\nPrecio de venta: Q." + precio+ ". \r\nPrecio en dólares: $." + Math.Round((precio/tipoCambioDolar),2)+ ". \r\n" + MostrarDisponibilidad();
            return Información;
        }

        public void AplicarDescuento(double miDescuento)
        {
            descuentoAplicado = miDescuento;
            precio = precio - descuentoAplicado;
        }

        internal void DefinirModelo(TextBox textBox1)
        {
            throw new NotImplementedException();
        }
    }
}
