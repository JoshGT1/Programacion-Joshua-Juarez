﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    public static double calcularPrecio(string tipoHelado, int topping)
    {
        double precio = 0;
        if (tipoHelado == "chocolate" || tipoHelado == "vainilla" || tipoHelado == "fresa")
        {
            precio = 5;
        }
        else if (tipoHelado == "napolitano" || tipoHelado == "pistacho")
        {
            precio = 7;
        }
        switch (topping)
        {
            case 1: // cobertura de chocolate
                precio = precio + 1;
                break;
            case 2: // cobertura de chocolate con manía
                precio = precio + 2;
                break;
            case 3: // cobertura de chocolate con anicillos
                precio = precio + 1;
                break;
                /* En caso de que el cliente no eligió un número de los rangos que se presentan sale este mensaje de error
                 * del porque no se sumó el precio del topping y por default el por qué su helado no lleva topping.*/
            default:
                Console.WriteLine("ERROR: El número que eligió no está dentro de nuestro rango de números para toppings");
                break;
        }
        return precio;
    }

    static void Main()
    {
        Console.WriteLine("Reto 3 \nJoshua Juárez (1185322); Bryan Quiñónez (1221622)");
        // Código para probar que la función funcione correctamente
        int contar=1;
        for (int tooping = 1; tooping < 4; tooping++)
        {
            Console.WriteLine("Helado chocolate con el topping: " + contar);
            Console.WriteLine(calcularPrecio("chocolate", tooping));
            contar++;
        }
        contar = 1;
        for (int tooping = 1; tooping < 4; tooping++)
        {
            Console.WriteLine("Helado napolitano con el topping: " + contar);
            Console.WriteLine(calcularPrecio("napolitano", tooping));
            contar++;
        }
        Console.WriteLine("\nEn caso de que no se haya elegido un topping correctamente:");
        Console.WriteLine("Helado chocolate con el topping: 0");
        Console.WriteLine(calcularPrecio("chocolate", 0));
        Console.ReadKey();
    }
}
