﻿namespace T9_JAJF1185322
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Texto_Modelo = new System.Windows.Forms.Label();
            this.Texto_Precio = new System.Windows.Forms.Label();
            this.Texto_Marca = new System.Windows.Forms.Label();
            this.Texto_PorcentajeIVA = new System.Windows.Forms.Label();
            this.Box_Modelo = new System.Windows.Forms.TextBox();
            this.Box_Precio = new System.Windows.Forms.TextBox();
            this.Box_Marca = new System.Windows.Forms.TextBox();
            this.Box_IVA = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.MostrarInformacion = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(235, 231);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.Box_IVA);
            this.tabPage1.Controls.Add(this.Box_Marca);
            this.tabPage1.Controls.Add(this.Box_Precio);
            this.tabPage1.Controls.Add(this.Box_Modelo);
            this.tabPage1.Controls.Add(this.Texto_PorcentajeIVA);
            this.tabPage1.Controls.Add(this.Texto_Marca);
            this.tabPage1.Controls.Add(this.Texto_Precio);
            this.tabPage1.Controls.Add(this.Texto_Modelo);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(227, 205);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ingreso de Datos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.MostrarInformacion);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(227, 205);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Datos Motocicleta";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Texto_Modelo
            // 
            this.Texto_Modelo.AutoSize = true;
            this.Texto_Modelo.Location = new System.Drawing.Point(19, 22);
            this.Texto_Modelo.Name = "Texto_Modelo";
            this.Texto_Modelo.Size = new System.Drawing.Size(45, 13);
            this.Texto_Modelo.TabIndex = 0;
            this.Texto_Modelo.Text = "Modelo:";
            // 
            // Texto_Precio
            // 
            this.Texto_Precio.AutoSize = true;
            this.Texto_Precio.Location = new System.Drawing.Point(19, 48);
            this.Texto_Precio.Name = "Texto_Precio";
            this.Texto_Precio.Size = new System.Drawing.Size(40, 13);
            this.Texto_Precio.TabIndex = 1;
            this.Texto_Precio.Text = "Precio:";
            // 
            // Texto_Marca
            // 
            this.Texto_Marca.AutoSize = true;
            this.Texto_Marca.Location = new System.Drawing.Point(19, 73);
            this.Texto_Marca.Name = "Texto_Marca";
            this.Texto_Marca.Size = new System.Drawing.Size(40, 13);
            this.Texto_Marca.TabIndex = 2;
            this.Texto_Marca.Text = "Marca:";
            // 
            // Texto_PorcentajeIVA
            // 
            this.Texto_PorcentajeIVA.AutoSize = true;
            this.Texto_PorcentajeIVA.Location = new System.Drawing.Point(19, 101);
            this.Texto_PorcentajeIVA.Name = "Texto_PorcentajeIVA";
            this.Texto_PorcentajeIVA.Size = new System.Drawing.Size(93, 13);
            this.Texto_PorcentajeIVA.TabIndex = 3;
            this.Texto_PorcentajeIVA.Text = "Porcentaje de IVA";
            // 
            // Box_Modelo
            // 
            this.Box_Modelo.Location = new System.Drawing.Point(118, 19);
            this.Box_Modelo.Name = "Box_Modelo";
            this.Box_Modelo.Size = new System.Drawing.Size(85, 20);
            this.Box_Modelo.TabIndex = 4;
            // 
            // Box_Precio
            // 
            this.Box_Precio.Location = new System.Drawing.Point(118, 45);
            this.Box_Precio.Name = "Box_Precio";
            this.Box_Precio.Size = new System.Drawing.Size(85, 20);
            this.Box_Precio.TabIndex = 5;
            // 
            // Box_Marca
            // 
            this.Box_Marca.Location = new System.Drawing.Point(118, 73);
            this.Box_Marca.Name = "Box_Marca";
            this.Box_Marca.Size = new System.Drawing.Size(85, 20);
            this.Box_Marca.TabIndex = 6;
            // 
            // Box_IVA
            // 
            this.Box_IVA.Location = new System.Drawing.Point(118, 101);
            this.Box_IVA.Name = "Box_IVA";
            this.Box_IVA.Size = new System.Drawing.Size(85, 20);
            this.Box_IVA.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(59, 127);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Ingresar Datos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MostrarInformacion
            // 
            this.MostrarInformacion.Enabled = false;
            this.MostrarInformacion.Location = new System.Drawing.Point(6, 6);
            this.MostrarInformacion.Multiline = true;
            this.MostrarInformacion.Name = "MostrarInformacion";
            this.MostrarInformacion.Size = new System.Drawing.Size(212, 174);
            this.MostrarInformacion.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 26);
            this.label1.TabIndex = 9;
            this.label1.Text = "IMPORTANTE: Ingresar el IVA en \r\ndecimales en el rango de 0.01 y 0.99.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 252);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox Box_IVA;
        private System.Windows.Forms.TextBox Box_Marca;
        private System.Windows.Forms.TextBox Box_Precio;
        private System.Windows.Forms.TextBox Box_Modelo;
        private System.Windows.Forms.Label Texto_PorcentajeIVA;
        private System.Windows.Forms.Label Texto_Marca;
        private System.Windows.Forms.Label Texto_Precio;
        private System.Windows.Forms.Label Texto_Modelo;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox MostrarInformacion;
        private System.Windows.Forms.Label label1;
    }
}

