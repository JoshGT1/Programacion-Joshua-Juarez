﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace T9_JAJF1185322
{
    internal class Motocicleta
    {
        private int Modelo;
        private double Precio;
        private string Marca;
        private double Iva;

        public Motocicleta()
        {
            this.Modelo = 2019;
            this.Precio = 1000;
            this.Marca = "";
            this.Iva = 0.12;
        }

        public void CambiarModelo(int Modelo1)
        {
            Modelo = Modelo1;
        }

        public void CambiarMarca(string Marca1)
        {
            Marca = Marca1;
        }

        public string MostrarDatos()
        {
            string Información = "Modelo: " + Modelo + ". \r\nPrecio de venta: Q." + PrecioConIva() + ". \r\nMarca: " + Marca + ". \r\nIVA: " + Iva + ". \r\nPrecio sin IVA: " + PrecioSinIva() + ". \r\nPrecio con IVA: " + PrecioConIva() + ". \r\nMonto solamente del IVA: " + DevolverIva() + ".";
            return Información;
        }

        public void DefinirPrecio(double PrecioMoto)
        {
            Precio = PrecioMoto;
        }

        public void DefinirIva(double IVA)
        {
            if (IVA <= 0.99)
            {
                if (IVA >= 0.01)
                {
                    Iva = IVA;
                }
            }
        }

        public double PrecioSinIva()
        {
            return Precio;
        }

        public double PrecioConIva()
        {
            double PrecioMotoIva = Precio + (Precio * Iva);
            return PrecioMotoIva;
        }

        public double DevolverIva()
        {
            double PrecioSoloIva = Precio * Iva;
            return PrecioSoloIva;
        }
    }
}
