﻿int reboot = 1;
while (reboot<2)
{
    reboot++;
    Console.WriteLine("Ingrese la vocal que quiere que la consola le dibuje (A, E, I, O, U)");
    string letras = Console.ReadLine();
    int conteo = 0;
    int conteo2 = 0;
    int conteo3 = 15;
    int conteo4 = 12;
    switch (letras)
    {
        case "A":
            Console.Clear();
            while (conteo < 8)
            {
                while (conteo2 < 9)
                {
                    Console.Write("x\t");
                    conteo2++;
                }
                Console.WriteLine("\n\nx\t\t\t\t\t\t\t\tx");
                conteo++;
                conteo3++;
                while (conteo3 > 17)
                {
                    conteo2 = 0;
                    conteo3 = 0;
                    Console.WriteLine(" ");
                }
            }
            Console.ReadKey();
            break;

        case "E":
            Console.Clear();
            while (conteo < 7)
            {
                while (conteo2 < 9)
                {
                    Console.Write("x\t");
                    conteo2++;
                }
                Console.WriteLine("\n\nx");
                conteo++;
                conteo3++;
                conteo4++;
                while (conteo3 > 18)
                {
                    conteo2 = 0;
                    conteo3 = 0;
                    Console.WriteLine(" ");
                }
                while (conteo4 > 18)
                {
                    conteo2 = 0;
                    Console.WriteLine();
                    while (conteo2 < 9)
                    {
                        Console.Write("x\t");
                        conteo2++;
                    }
                    conteo4 = 0;
                    Console.WriteLine(" ");
                }
            }
            Console.ReadKey();
            break;

        case "I":
            Console.Clear();
            while (conteo < 8)
            {
                while (conteo2 < 9)
                {
                    Console.Write("x\t");
                    conteo2++;
                }
                Console.WriteLine("\n\n\t\t\t\tx\t\t\t\t");
                conteo++;
            }
            Console.WriteLine(" ");
            conteo2 = 0;
            while (conteo2 < 9)
            {
                Console.Write("x\t");
                conteo2++;
            }
            Console.ReadKey();
            break;

        case "O":
            Console.Clear();
            while (conteo < 8)
            {
                while (conteo2 < 9)
                {
                    Console.Write("x\t");
                    conteo2++;
                }
                Console.WriteLine("\n\nx\t\t\t\t\t\t\t\tx");
                conteo++;
            }
            Console.WriteLine(" ");
            conteo2 = 0;
            while (conteo2 < 9)
            {
                Console.Write("x\t");
                conteo2++;
            }
            Console.ReadKey();
            break;

        case "U":
            Console.Clear();
            while (conteo < 9)
            {
                Console.WriteLine("x\t\t\t\t\t\t\t\tx\n");
                conteo++;
            }
            while (conteo2 < 9)
            {
                Console.Write("x\t");
                conteo2++;
            }
            Console.ReadKey();
            break;

        default:
            Console.WriteLine("Error: Ingrese la vocal en mayúscula");
            reboot = reboot - 1;
            break;
    }
}
