﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{

    static void Main(string[] args)
    {
        double PrimerNumero;
        double SegundoNumero;
        bool Rebooot = false;
        Console.WriteLine("Integrantes y Carné: Joshua Juárez (1185322); Bryan Quiñónez (1221622)");
        Console.WriteLine("Reto #2: Juego de Sumas");
        Console.WriteLine("Ingrese su primer sumando (Primer número)");
        PrimerNumero=Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Ingrese su segundo sumando (Segundo número)");
        SegundoNumero=Convert.ToDouble(Console.ReadLine());
        JuegoSuma objJuegoSuma = new JuegoSuma(PrimerNumero, SegundoNumero);
        objJuegoSuma.SumarNumeros();
        Console.WriteLine("¿Cuál es el resultado de la suma de los anteriores sumandos ingresados?");   
        while (Rebooot == false)
        {
            objJuegoSuma.CorrectoOIncorrecto(Console.ReadLine());
            objJuegoSuma.CambiarRebooot(ref Rebooot);
        }
        Console.ReadKey();
    }
}



class JuegoSuma
{
    private double Numero1;
    private double Numero2;
    private double ResultadoT;
    private bool reset = false;

    public JuegoSuma(double numero1, double numero2)
    {
        Numero1 = numero1;
        Numero2 = numero2;
    }

    public void SumarNumeros()
    {
        double Resultado = Numero1 + Numero2;
        ResultadoT = Resultado;
    }

    public void CorrectoOIncorrecto(string respuesta)
    {
        if ( Convert.ToDouble(respuesta) == ResultadoT)
        {
            Console.WriteLine("Es correcta su respuesta. ¡Felicitaciones!");
            reset = true;
        }
        else
        {
            Console.WriteLine("No es correcta su respuesta, intente de nuevo");
        }
    }
    public void CambiarRebooot(ref bool Reset)
    {
        Reset = reset;
    }
}
