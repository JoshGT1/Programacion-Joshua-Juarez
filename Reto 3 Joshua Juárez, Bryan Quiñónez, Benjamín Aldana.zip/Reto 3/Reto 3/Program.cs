﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] niveles = new int[5];
            int[] adultos = new int[5];
            int[] niños = new int[5];
            int[] personas = new int[5];
            string[] responsable = new string[5];
            int nivel = 1;
            for (int i = 0; i < 5; i++)
            {
                niveles[i] = nivel;
                Console.WriteLine("Ingrese el número de adultos que están en el nivel: " + nivel);
                adultos[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el número de niños que están en el nivel: " + nivel);
                niños[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el nombre del responsable del nivel: " + nivel);
                responsable[i] = (Console.ReadLine());
                nivel++;
            }
            for (int i = 0; i < 5; i++)
            {
                personas[i] = adultos[i] + niños[i];
            }
            Console.Clear();
            int mayor = personas[0];
            for (int i = 1; i < 5; i++)
            {
                if (personas[i] > mayor)
                {
                    mayor = personas[i];
                }
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Nivel: " + niveles[i] + "\n");
                Console.WriteLine("Responsable del nivel: " + responsable[i]);
                Console.WriteLine("Número de adultos viviendo: " + adultos[i]);
                Console.WriteLine("Número de niños viviendo: " + niños[i]);
                Console.WriteLine("Número de personas viviendo:" + personas[i] + "\n");

            }
            for (int i = 0; i < 5; i++)
            {
                if (personas[i] == mayor)
                {
                    Console.WriteLine("Responsable con mayor cantidad de personas: " + responsable[i]);
                }
            }
            Console.ReadKey();
        }
    }
}